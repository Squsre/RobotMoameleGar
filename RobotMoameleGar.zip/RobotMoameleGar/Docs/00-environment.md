# Environment Info — RobotMoameleGar

## MetaTrader 5
- Version: 5.00
- Build: 6240
- Broker: MetaQuotes Ltd.
- Data Folder: C:\Users\Rayan\AppData\Roaming\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\MQL5

## Demo Account
- Server: MetaQuotes-Demo
- Login: 113666043
- Password: @iSyZ7Qm
- Account Type: Forex Hedged USD
- Leverage: 1:100
- Initial Deposit: 3000 USD
- Use Hedge: Yes

## MetaEditor
- Build: 6240
- Default Compile Target: MQL5\Experts\RobotMoameleGar\

## Project Structure
MQL5\Experts\RobotMoameleGar\
├── RobotMoameleGar.mq5     (فایل اصلی EA — هنوز ساخته نشده)
├── Include\                (هدرهای اختصاصی پروژه)
├── Presets\                (فایل‌های .set برای بک‌تست)
└── Docs\                   (مستندات)

## Trading Config
- Symbol: EURUSD
- Timeframe (پیشنهادی شروع): H4
- Magic Number (پیشنهادی): 20260101

## Notes
- حساب دمو روی سرور رسمی MetaQuotes — بدون KYC، مناسب تست سریع.
- Data Folder path از نوع Roaming/Portable است و در بک‌آپ‌گیری مهم است.
- نسخه build 6240 از MT5 — سازگار با آخرین ویژگی‌های زبان MQL5.
- برای فاز ML آینده، ستون‌های جداگانه در فایل CSV ساخته خواهد شد.