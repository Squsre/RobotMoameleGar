//+------------------------------------------------------------------+
//|                                                     Common.mqh   |
//|            Shared enums, structs and constants                   |
//+------------------------------------------------------------------+
#ifndef __COMMON_MQH__
#define __COMMON_MQH__

//====================================================================
//  Project identity
//====================================================================
#define ROBOT_NAME     "RobotMoameleGar"
#define ROBOT_VERSION  "1.000"

//====================================================================
//  Signal direction returned by the strategy layer
//====================================================================
enum ENUM_SIGNAL
{
   SIGNAL_NONE = 0,   // No signal
   SIGNAL_BUY  = 1,   // Buy signal
   SIGNAL_SELL = -1   // Sell signal
};

//====================================================================
//  Trade direction (used by risk / trade layers)
//====================================================================
enum ENUM_TRADE_DIR
{
   TRADE_BUY  = 0,
   TRADE_SELL = 1
};

//====================================================================
//  Signal context — carries everything the strategy wants to pass
//  to the risk / trade layers.
//====================================================================
struct SignalInfo
{
   ENUM_SIGNAL signal;    // SIGNAL_BUY / SIGNAL_SELL / SIGNAL_NONE
   double      price;     // close price of the signal bar
   double      atr;       // ATR value at the signal bar
   datetime    barTime;   // open time of the signal bar
};

#endif // __COMMON_MQH__
//+------------------------------------------------------------------+