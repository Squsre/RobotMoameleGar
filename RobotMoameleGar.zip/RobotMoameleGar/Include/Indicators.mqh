//+------------------------------------------------------------------+
//|                                                 Indicators.mqh   |
//|            Indicator handles + value readers                     |
//+------------------------------------------------------------------+
#ifndef __INDICATORS_MQH__
#define __INDICATORS_MQH__

#include "Common.mqh"
#include "Inputs.mqh"

//====================================================================
//  Module-local handles
//====================================================================
int g_hEmaFast   = INVALID_HANDLE;
int g_hEmaSlow   = INVALID_HANDLE;
int g_hEmaFilter = INVALID_HANDLE;
int g_hAdx       = INVALID_HANDLE;
int g_hAtr       = INVALID_HANDLE;

//====================================================================
//| InitIndicators                                                   |
//====================================================================
bool InitIndicators()
{
   g_hEmaFast = iMA(_Symbol, InpTimeframe, InpEmaFast, 0, MODE_EMA, PRICE_CLOSE);
   if(g_hEmaFast == INVALID_HANDLE)
   {
      PrintFormat("[ERROR] iMA(EMA fast, period=%d) failed. LastError=%d",
                  InpEmaFast, GetLastError());
      return(false);
   }

   g_hEmaSlow = iMA(_Symbol, InpTimeframe, InpEmaSlow, 0, MODE_EMA, PRICE_CLOSE);
   if(g_hEmaSlow == INVALID_HANDLE)
   {
      PrintFormat("[ERROR] iMA(EMA slow, period=%d) failed. LastError=%d",
                  InpEmaSlow, GetLastError());
      return(false);
   }

   g_hEmaFilter = iMA(_Symbol, InpTimeframe, InpEmaFilter, 0, MODE_EMA, PRICE_CLOSE);
   if(g_hEmaFilter == INVALID_HANDLE)
   {
      PrintFormat("[ERROR] iMA(EMA filter, period=%d) failed. LastError=%d",
                  InpEmaFilter, GetLastError());
      return(false);
   }

   g_hAdx = iADX(_Symbol, InpTimeframe, InpAdxPeriod);
   if(g_hAdx == INVALID_HANDLE)
   {
      PrintFormat("[ERROR] iADX(period=%d) failed. LastError=%d",
                  InpAdxPeriod, GetLastError());
      return(false);
   }

   g_hAtr = iATR(_Symbol, InpTimeframe, InpAtrPeriod);
   if(g_hAtr == INVALID_HANDLE)
   {
      PrintFormat("[ERROR] iATR(period=%d) failed. LastError=%d",
                  InpAtrPeriod, GetLastError());
      return(false);
   }

   PrintFormat("[OK] 5 indicator handles created on %s %s",
               _Symbol, EnumToString(InpTimeframe));
   return(true);
}

//====================================================================
//| ReleaseIndicators                                                |
//====================================================================
void ReleaseIndicators()
{
   if(g_hEmaFast   != INVALID_HANDLE) { IndicatorRelease(g_hEmaFast);   g_hEmaFast   = INVALID_HANDLE; }
   if(g_hEmaSlow   != INVALID_HANDLE) { IndicatorRelease(g_hEmaSlow);   g_hEmaSlow   = INVALID_HANDLE; }
   if(g_hEmaFilter != INVALID_HANDLE) { IndicatorRelease(g_hEmaFilter); g_hEmaFilter = INVALID_HANDLE; }
   if(g_hAdx       != INVALID_HANDLE) { IndicatorRelease(g_hAdx);       g_hAdx       = INVALID_HANDLE; }
   if(g_hAtr       != INVALID_HANDLE) { IndicatorRelease(g_hAtr);       g_hAtr       = INVALID_HANDLE; }

   Print("[OK] Indicator handles released");
}

//====================================================================
//| Low-level reader                                                 |
//| Reads 1 value from a buffer at a given shift.                    |
//| Returns false if the buffer isn't ready (data not yet loaded).   |
//====================================================================
bool ReadBuffer(int handle, int bufferIndex, int shift, double &outValue)
{
   double tmp[];
   if(CopyBuffer(handle, bufferIndex, shift, 1, tmp) != 1)
      return(false);
   outValue = tmp[0];
   return(true);
}

//====================================================================
//| High-level getters — default shift = 1 (last closed bar)         |
//| Return EMPTY_VALUE on failure so callers can detect easily.      |
//====================================================================

//--- Fast EMA
double GetEmaFast(int shift = 1)
{
   double v;
   if(!ReadBuffer(g_hEmaFast, 0, shift, v)) return(EMPTY_VALUE);
   return(v);
}

//--- Slow EMA
double GetEmaSlow(int shift = 1)
{
   double v;
   if(!ReadBuffer(g_hEmaSlow, 0, shift, v)) return(EMPTY_VALUE);
   return(v);
}

//--- Filter EMA (200)
double GetEmaFilter(int shift = 1)
{
   double v;
   if(!ReadBuffer(g_hEmaFilter, 0, shift, v)) return(EMPTY_VALUE);
   return(v);
}

//--- ADX main line (buffer 0)
double GetAdx(int shift = 1)
{
   double v;
   if(!ReadBuffer(g_hAdx, 0, shift, v)) return(EMPTY_VALUE);
   return(v);
}

//--- ATR
double GetAtr(int shift = 1)
{
   double v;
   if(!ReadBuffer(g_hAtr, 0, shift, v)) return(EMPTY_VALUE);
   return(v);
}

#endif // __INDICATORS_MQH__
//+------------------------------------------------------------------+