//+------------------------------------------------------------------+
//|                                                     Inputs.mqh   |
//|                  All user-configurable parameters                |
//+------------------------------------------------------------------+
#ifndef __INPUTS_MQH__
#define __INPUTS_MQH__

#include "Common.mqh"

//====================================================================
//  General
//====================================================================
input group "=== General ==="
input ulong            InpMagic            = 20260101;    // Magic number
input int              InpSlippagePoints   = 20;          // Slippage (points)
input ENUM_TIMEFRAMES  InpTimeframe        = PERIOD_H4;   // Working timeframe

//====================================================================
//  Indicator parameters
//====================================================================
input group "=== Indicators ==="
input int     InpEmaFast      = 20;     // Fast EMA period
input int     InpEmaSlow      = 50;     // Slow EMA period
input int     InpEmaFilter    = 200;    // Filter EMA period (trend)
input int     InpAdxPeriod    = 14;     // ADX period
input double  InpAdxThreshold = 22.0;   // ADX minimum to allow entry
input int     InpAtrPeriod    = 14;     // ATR period

//====================================================================
//  Risk management
//====================================================================
input group "=== Risk Management ==="
input double  InpRiskPercent     = 1.0;   // Risk per trade (% of balance)
input double  InpAtrSlMultiplier = 1.5;   // SL distance = ATR * this
input double  InpRewardRatio     = 1.5;   // TP distance = SL * this
input double  InpMinLot          = 0.01;  // Minimum allowed lot
input double  InpMaxLot          = 100.0; // Maximum allowed lot

//====================================================================
//  Behavior
//====================================================================
input group "=== Behavior ==="
input bool    InpReverseOnOpposite = true; // Close and reverse on opposite signal

#endif // __INPUTS_MQH__
//+------------------------------------------------------------------+