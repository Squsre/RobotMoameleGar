//+------------------------------------------------------------------+
//|                                                        Risk.mqh  |
//|            SL/TP calculation and position sizing                 |
//+------------------------------------------------------------------+
#ifndef __RISK_MQH__
#define __RISK_MQH__

#include "Common.mqh"
#include "Inputs.mqh"

//====================================================================
//| NormalizePrice                                                   |
//| Rounds a price to the symbol's tick size.                        |
//====================================================================
double NormalizePrice(double price)
{
   double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickSize <= 0.0)
      return(NormalizeDouble(price, _Digits));

   return(NormalizeDouble(MathRound(price / tickSize) * tickSize, _Digits));
}

//====================================================================
//| CalcSL                                                           |
//| Returns the stop-loss price.                                     |
//|   direction: TRADE_BUY or TRADE_SELL                             |
//|   atr      : ATR value at signal bar                             |
//|   price    : entry price (signal bar close)                      |
//====================================================================
double CalcSL(ENUM_TRADE_DIR direction, double atr, double price)
{
   double distance = atr * InpAtrSlMultiplier;
   if(distance <= 0.0)
      return(0.0);

   double sl = (direction == TRADE_BUY)
               ? price - distance
               : price + distance;

   return(NormalizePrice(sl));
}

//====================================================================
//| CalcTP                                                           |
//| Returns the take-profit price based on R:R.                      |
//====================================================================
double CalcTP(ENUM_TRADE_DIR direction, double price, double sl)
{
   double slDistance = MathAbs(price - sl);
   if(slDistance <= 0.0)
      return(0.0);

   double tpDistance = slDistance * InpRewardRatio;

   double tp = (direction == TRADE_BUY)
               ? price + tpDistance
               : price - tpDistance;

   return(NormalizePrice(tp));
}

//====================================================================
//| CalcLot                                                          |
//| Computes lot size from risk % and SL distance in price units.    |
//| Uses SYMBOL_TRADE_TICK_VALUE / TICK_SIZE → works on any symbol   |
//| and any digit-count (4/5 digits, gold, indices, ...).            |
//====================================================================
double CalcLot(double riskPercent, double slDistance)
{
   if(riskPercent <= 0.0 || slDistance <= 0.0)
      return(0.0);

   double balance   = AccountInfoDouble(ACCOUNT_BALANCE);
   double riskMoney = balance * riskPercent / 100.0;

   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);

   if(tickValue <= 0.0 || tickSize <= 0.0)
   {
      Print("[ERROR] CalcLot: tick value/size unavailable");
      return(0.0);
   }

   //--- Loss per 1 lot if SL is hit
   double lossPerLot = (slDistance / tickSize) * tickValue;
   if(lossPerLot <= 0.0)
      return(0.0);

   //--- Raw lot
   double rawLot = riskMoney / lossPerLot;

   //--- Round to lot step
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   if(lotStep <= 0.0)
      lotStep = 0.01;

   double lot = MathFloor(rawLot / lotStep) * lotStep;

   //--- Clamp to symbol limits and user inputs
   lot = MathMax(lot, InpMinLot);
   lot = MathMin(lot, InpMaxLot);
   lot = MathMin(lot, maxLot);
   lot = MathMax(lot, minLot);

   //--- Round to 2 decimals (typical lot precision)
   return(NormalizeDouble(lot, 2));
}

//====================================================================
//| PrintRiskPreview                                                 |
//| Debug helper — prints computed SL/TP/lot for a signal.           |
//====================================================================
void PrintRiskPreview(ENUM_TRADE_DIR direction, double price, double atr)
{
   double sl = CalcSL(direction, atr, price);
   if(sl == 0.0) { Print("[Risk] SL calculation failed"); return; }

   double tp   = CalcTP(direction, price, sl);
   double dist = MathAbs(price - sl);
   double lot  = CalcLot(InpRiskPercent, dist);

   string dirStr = (direction == TRADE_BUY) ? "BUY" : "SELL";

   PrintFormat("[Risk] %s | entry=%.5f SL=%.5f TP=%.5f | slDist=%.5f | lot=%.2f | risk=%.2f%%",
               dirStr, price, sl, tp, dist, lot, InpRiskPercent);
}

#endif // __RISK_MQH__
//+------------------------------------------------------------------+