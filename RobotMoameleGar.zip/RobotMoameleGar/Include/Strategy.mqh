//+------------------------------------------------------------------+
//|                                                    Strategy.mqh  |
//|            Signal detection: EMA cross + EMA200 + ADX filters    |
//+------------------------------------------------------------------+
#ifndef __STRATEGY_MQH__
#define __STRATEGY_MQH__

#include "Common.mqh"
#include "Inputs.mqh"
#include "Indicators.mqh"

//====================================================================
//| CheckSignal                                                      |
//| Evaluates signal conditions on the LAST CLOSED bar.              |
//| Returns SignalInfo:                                              |
//|   - signal  : SIGNAL_BUY / SIGNAL_SELL / SIGNAL_NONE             |
//|   - price   : close price of the signal bar (shift=1)            |
//|   - atr     : ATR value at the signal bar                        |
//|   - barTime : open time of the signal bar                        |
//|                                                                  |
//|   Returns SIGNAL_NONE and zeroed struct on insufficient data.    |
//====================================================================
SignalInfo CheckSignal()
{
   SignalInfo info;
   info.signal  = SIGNAL_NONE;
   info.price   = 0.0;
   info.atr     = 0.0;
   info.barTime = 0;

   //--- Read EMAs at shift 1 (closed bar) and shift 2 (previous closed bar)
   double emaFast1 = GetEmaFast(1);
   double emaFast2 = GetEmaFast(2);
   double emaSlow1 = GetEmaSlow(1);
   double emaSlow2 = GetEmaSlow(2);

   //--- Sanity check — any indicator not ready yet?
   if(emaFast1 == EMPTY_VALUE || emaFast2 == EMPTY_VALUE ||
      emaSlow1 == EMPTY_VALUE || emaSlow2 == EMPTY_VALUE)
   {
      return(info);
   }

   //--- Cross detection on closed bars only
   bool crossUp   = (emaFast1 > emaSlow1) && (emaFast2 <= emaSlow2);
   bool crossDown = (emaFast1 < emaSlow1) && (emaFast2 >= emaSlow2);

   if(!crossUp && !crossDown)
      return(info);  // no cross → no signal

   //--- Read filters
   double emaFilter1 = GetEmaFilter(1);
   double adx1       = GetAdx(1);
   double atr1       = GetAtr(1);

   if(emaFilter1 == EMPTY_VALUE || adx1 == EMPTY_VALUE || atr1 == EMPTY_VALUE)
      return(info);

   //--- ADX strength filter (common to both directions)
   if(adx1 <= InpAdxThreshold)
      return(info);  // trend not strong enough → no trade

   //--- Close price of the signal bar
   double close1 = iClose(_Symbol, InpTimeframe, 1);
   datetime bar1 = iTime(_Symbol, InpTimeframe, 1);
   if(close1 == 0.0 || bar1 == 0)
      return(info);

   //--- BUY: cross up + price above EMA200
   if(crossUp && close1 > emaFilter1)
   {
      info.signal  = SIGNAL_BUY;
      info.price   = close1;
      info.atr     = atr1;
      info.barTime = bar1;
      return(info);
   }

   //--- SELL: cross down + price below EMA200
   if(crossDown && close1 < emaFilter1)
   {
      info.signal  = SIGNAL_SELL;
      info.price   = close1;
      info.atr     = atr1;
      info.barTime = bar1;
      return(info);
   }

   return(info);  // cross happened but filters rejected
}

#endif // __STRATEGY_MQH__
//+------------------------------------------------------------------+