//+------------------------------------------------------------------+
//|                                                       Trade.mqh  |
//|            Order execution via CTrade                            |
//+------------------------------------------------------------------+
#ifndef __TRADE_MQH__
#define __TRADE_MQH__

#include <Trade/Trade.mqh>
#include "Common.mqh"
#include "Inputs.mqh"

//====================================================================
//  Global CTrade instance
//====================================================================
CTrade g_trade;

//====================================================================
//| InitTrade                                                        |
//====================================================================
bool InitTrade()
{
   g_trade.SetExpertMagicNumber(InpMagic);
   g_trade.SetDeviationInPoints(InpSlippagePoints);
   g_trade.SetTypeFillingBySymbol(_Symbol);   // auto-select filling mode
   g_trade.SetAsyncMode(false);               // synchronous execution

   PrintFormat("[OK] Trade module initialized: magic=%I64u, deviation=%d, filling=auto",
               InpMagic, InpSlippagePoints);
   return(true);
}

//====================================================================
//| HasOpenPosition                                                  |
//| Basic safety check — expanded in Phase 8.                        |
//====================================================================
bool HasOpenPosition()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0)                                   continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if(PositionGetInteger(POSITION_MAGIC) != (long)InpMagic) continue;
      return(true);
   }
   return(false);
}

//====================================================================
//| PrintTradeError                                                  |
//====================================================================
void PrintTradeError(const string context)
{
   PrintFormat("[TRADE-ERROR] %s | retcode=%d (%s) | lastError=%d",
               context,
               g_trade.ResultRetcode(),
               g_trade.ResultRetcodeDescription(),
               GetLastError());
}

//====================================================================
//| OpenBuy                                                          |
//|  market entry (price=0), with absolute SL/TP.                    |
//====================================================================
bool OpenBuy(double lot, double sl, double tp, string comment = "")
{
   if(lot <= 0.0)         { Print("[ERROR] OpenBuy: invalid lot");    return(false); }
   if(sl <= 0.0 || tp <= 0.0) { Print("[ERROR] OpenBuy: invalid SL/TP"); return(false); }

   bool ok = g_trade.Buy(lot, _Symbol, 0.0, sl, tp, comment);
   if(!ok) { PrintTradeError("Buy"); return(false); }

   PrintFormat("[TRADE] BUY  filled: ticket=%I64u lot=%.2f fillPrice=%.5f SL=%.5f TP=%.5f",
               g_trade.ResultOrder(), g_trade.ResultVolume(),
               g_trade.ResultPrice(), sl, tp);
   return(true);
}

//====================================================================
//| OpenSell                                                         |
//====================================================================
bool OpenSell(double lot, double sl, double tp, string comment = "")
{
   if(lot <= 0.0)         { Print("[ERROR] OpenSell: invalid lot");    return(false); }
   if(sl <= 0.0 || tp <= 0.0) { Print("[ERROR] OpenSell: invalid SL/TP"); return(false); }

   bool ok = g_trade.Sell(lot, _Symbol, 0.0, sl, tp, comment);
   if(!ok) { PrintTradeError("Sell"); return(false); }

   PrintFormat("[TRADE] SELL filled: ticket=%I64u lot=%.2f fillPrice=%.5f SL=%.5f TP=%.5f",
               g_trade.ResultOrder(), g_trade.ResultVolume(),
               g_trade.ResultPrice(), sl, tp);
   return(true);
}

#endif // __TRADE_MQH__
//+------------------------------------------------------------------+