//+------------------------------------------------------------------+
//|                                             RobotMoameleGar.mq5  |
//|                        Rule-based EMA Cross EA (EURUSD, MQL5)    |
//+------------------------------------------------------------------+
#property copyright "Amir"
#property link      ""
#property version   "1.000"
#property description "Rule-based EA: EMA Cross + EMA200 Filter + ADX Filter (EURUSD)"
#property strict

//====================================================================
//  Includes
//====================================================================
#include "Include/Common.mqh"
#include "Include/Inputs.mqh"
#include "Include/Indicators.mqh"
#include "Include/Strategy.mqh"
#include "Include/Risk.mqh"
#include "Include/Trade.mqh"

//====================================================================
//| Expert initialization function                                    |
//====================================================================
int OnInit()
{
   PrintFormat("=== %s v%s initialized ===", ROBOT_NAME, ROBOT_VERSION);
   PrintFormat("Build datetime: %s", TimeToString(__DATETIME__, TIME_DATE|TIME_MINUTES));

   //--- Input validation
   if(InpEmaFast <= 1 || InpEmaSlow <= 1 || InpEmaFilter <= 1)
   {
      Print("[ERROR] EMA periods must be > 1");
      return(INIT_PARAMETERS_INCORRECT);
   }
   if(InpEmaFast >= InpEmaSlow)
   {
      Print("[ERROR] Fast EMA must be smaller than Slow EMA");
      return(INIT_PARAMETERS_INCORRECT);
   }
   if(InpEmaSlow >= InpEmaFilter)
      Print("[WARN] Slow EMA >= Filter EMA — trend filter may misbehave");

   if(InpAdxPeriod <= 1 || InpAtrPeriod <= 1)
   {
      Print("[ERROR] ADX / ATR period must be > 1");
      return(INIT_PARAMETERS_INCORRECT);
   }
   if(InpRiskPercent <= 0.0 || InpRiskPercent > 100.0)
   {
      Print("[ERROR] Risk percent must be in (0, 100]");
      return(INIT_PARAMETERS_INCORRECT);
   }
   if(InpAtrSlMultiplier <= 0.0 || InpRewardRatio <= 0.0)
   {
      Print("[ERROR] ATR SL multiplier and Reward ratio must be > 0");
      return(INIT_PARAMETERS_INCORRECT);
   }

   //--- Print resolved inputs
   PrintFormat("Timeframe=%s | EMA fast=%d slow=%d filter=%d",
               EnumToString(InpTimeframe), InpEmaFast, InpEmaSlow, InpEmaFilter);
   PrintFormat("ADX period=%d threshold=%.1f | ATR period=%d",
               InpAdxPeriod, InpAdxThreshold, InpAtrPeriod);
   PrintFormat("Risk=%.2f%% | ATR*SL=%.2f | R:R = 1:%.2f | Reverse=%s",
               InpRiskPercent, InpAtrSlMultiplier, InpRewardRatio,
               InpReverseOnOpposite ? "ON" : "OFF");

   //--- Create indicator handles
   if(!InitIndicators())
   {
      Print("[ERROR] InitIndicators failed — EA will not start");
      return(INIT_FAILED);
   }

   //--- Setup CTrade
   if(!InitTrade())
   {
      Print("[ERROR] InitTrade failed — EA will not start");
      return(INIT_FAILED);
   }

   return(INIT_SUCCEEDED);
}

//====================================================================
//| Expert deinitialization function                                  |
//====================================================================
void OnDeinit(const int reason)
{
   PrintFormat("=== %s deinitializing. Reason code: %d ===", ROBOT_NAME, reason);

   ReleaseIndicators();
}

//====================================================================
//| Expert tick function                                              |
//====================================================================
void OnTick()
{
   //--- Only evaluate on new bar
   static datetime lastBar = 0;
   datetime curBar = iTime(_Symbol, InpTimeframe, 1);
   if(curBar == lastBar)
      return;
   lastBar = curBar;

   //--- Skip if position already open (placeholder until Phase 8)
   if(HasOpenPosition())
   {
      PrintFormat("Bar=%s | position already open — skip",
                  TimeToString(curBar, TIME_DATE|TIME_MINUTES));
      return;
   }

   //--- Evaluate signal
   SignalInfo sig = CheckSignal();
   if(sig.signal == SIGNAL_NONE)
   {
      PrintFormat("Bar=%s | no signal",
                  TimeToString(curBar, TIME_DATE|TIME_MINUTES));
      return;
   }

   ENUM_TRADE_DIR dir = (sig.signal == SIGNAL_BUY) ? TRADE_BUY : TRADE_SELL;
   string dirStr      = (sig.signal == SIGNAL_BUY) ? "BUY" : "SELL";

   //--- Risk calc
   double sl   = CalcSL(dir, sig.atr, sig.price);
   double tp   = CalcTP(dir, sig.price, sl);
   double dist = MathAbs(sig.price - sl);
   double lot  = CalcLot(InpRiskPercent, dist);

   PrintFormat("Bar=%s | SIGNAL=%s | price=%.5f ATR=%.5f | SL=%.5f TP=%.5f lot=%.2f",
               TimeToString(sig.barTime, TIME_DATE|TIME_MINUTES),
               dirStr, sig.price, sig.atr, sl, tp, lot);

   if(sl == 0.0 || tp == 0.0 || lot <= 0.0)
   {
      Print("[ERROR] Risk calc failed — skip trade");
      return;
   }

   //--- Execute
   string comment = "RC-" + dirStr;
   bool ok = (dir == TRADE_BUY)
             ? OpenBuy(lot, sl, tp, comment)
             : OpenSell(lot, sl, tp, comment);

   if(!ok)
      Print("[ERROR] Order execution failed");
}
//+------------------------------------------------------------------+